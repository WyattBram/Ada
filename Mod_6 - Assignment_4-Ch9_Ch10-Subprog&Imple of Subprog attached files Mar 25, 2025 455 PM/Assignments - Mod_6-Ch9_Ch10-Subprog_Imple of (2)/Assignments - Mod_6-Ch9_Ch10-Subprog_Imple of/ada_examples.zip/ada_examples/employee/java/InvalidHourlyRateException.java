public class InvalidHourlyRateException extends Exception
{

	public InvalidHourlyRateException (String message)
	{
		super (message);
	}
	
}
